$(()=>{
    $('form[name="form__order"]').submit(()=>{
        $.ajax({
            cache: false,
            type: 'GET',
            url: 'mail.php',
            data: $(this).serialize(),
            success: ()=> window.open('success.html', '_self'),
            error:()=> window.open('error.html', '_self')
        });
        return false;
    });
});