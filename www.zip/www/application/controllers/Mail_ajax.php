<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mail_ajax extends CI_Controller {

	public function index()
	{
		$name = $this->input->post('name');
		$phone = $this->input->post('phone');
		$email = $this->input->post('email');
/*
		$this->email->from('your@example.com', 'Your Name');
		$this->email->to('temfly85@gmail.com');

		$this->email->subject('Email Test');
		$this->email->message('Ваша заявка успешно принята!');

		$this->email->send();		
*/
		mail("ivanikiv777@gmail.com", "Новая заявка", "Заявка на разработку проекта\n Имя: $name\n Телефон: $phone\n Email: $email");		
		
		echo 'Ваша заявка успешно принята!';
		
//		redirect(base_url().'welcome/success');		
	}
}
