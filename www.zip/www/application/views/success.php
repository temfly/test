<!DOCTYPE html>
<html lang="uk">
<head>
	<meta charset="UTF-8">
	<meta name="description" content="Поспішай замовити за акційною ціною лише до 12 жовтня. Отримай чіткий план розробки твого інтернет магазину, кошторис та рекомендації щодо запуску.">
	<meta name="keywords" content="Shopfactory, спеціальна пропозиція, інтернет магазини, акційною ціною">
  	<meta name="author" content="xCode">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>"Shopfactory" - розробка сучасних інтернет магазинів та подальше їх обслуговування</title>
	<link rel="shortcut icon" href="<? echo base_url() ?>images/favicon.ico" type="image/x-icon">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="<? echo base_url() ?>style/success.css">
	<link rel="stylesheet" href="<? echo base_url() ?>style/responsive.css">
</head>
<body>
	<header class="header">
		<div class="container">
			<div class="row">
				<div class="logo offset-1">
					<img src="<? echo base_url() ?>images/logo.png" alt="Logotype" class="logo__img img-fluid">
				</div>
				<div class="tel ml-auto">+38(068)-95-99-432</div>
				<div class="col-1"></div>
			</div>
		</div>
	</header>
	<main class="main">
		<div class="container">
			<div class="content">
				<h1>ДЯКУЄМО ЗА ЗАЯВКУ</h1>
				<p>Ваша заявка прийнята. Скоро наш менеджер з Вами звяжеться для вирішення всіх питаннь, пов’язаних з планом запуску</p>
				<div>
					<a href="<? echo base_url() ?>" class="btm">Повернутись “на головну”</a>
				</div>
			</div>
		</div>
	</main>
	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="logo offset-1">
					<img src="<? echo base_url() ?>images/logo.png" alt="Logotype" class="logo__img">
				</div>
			<div class="copyright offset-2 offset-sm-3 offset-md-4">© All rights reserved</div>
			</div>
		</div>
	</footer>
</body>
</html>