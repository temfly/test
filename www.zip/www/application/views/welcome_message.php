<!DOCTYPE html>
<html lang="uk">
<head>
	<meta charset="UTF-8">
	<meta name="description" content="Поспішай замовити за акційною ціною лише до 12 жовтня. Отримай чіткий план розробки твого інтернет магазину, кошторис та рекомендації щодо запуску.">
	<meta name="keywords" content="Shopfactory, спеціальна пропозиція, інтернет магазини, акційною ціною">
  	<meta name="author" content="xCode">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>"Shopfactory" - розробка сучасних інтернет магазинів та подальше їх обслуговування</title>
	<link rel="shortcut icon" href="<? echo base_url() ?>images/favicon.ico" type="image/x-icon">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<link rel="stylesheet" href="<? echo base_url() ?>style/index.css">
	<link rel="stylesheet" href="<? echo base_url() ?>style/responsive.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script>
		$(document).ready(function(){
			$('#send_data').click(function(){
				var name = $("#form__name").val();
				var phone = $("#form__tel").val();
				var email = $("#form__email").val();
				
				$.ajax({
					type: "POST",
					data: {
						'name' : name,
						'phone' : phone,
						'email' : email
					},
					url: '<? echo base_url() ?>index.php/mail_ajax',
					success: function(result){
						alert(result);
						window.location.href = '<? echo base_url() ?>index.php/welcome/success';

					},
					error: function(){
						window.location.href = '<? echo base_url() ?>index.php/welcome/error';

					}
				});
			});
		});
	</script>
</head>
<body>
	<header class="header">
		<div class="container">
			<div class="row">
				<div class="logo offset-1">
					<img src="<? echo base_url() ?>images/logo.png" alt="Logotype" class="logo__img img-fluid">
				</div>
				<div class="tel ml-auto">+38(068)-95-99-432</div>
				<div class="col-1"></div>
			</div>
		</div>
	</header>
	<main class="main">
		<div class="container">
			<div class="row">
				<h1>Почни продавати в інтернеті на новому рівні, замовивши інтернет магазин та рекламу в компанії "Shopfactory"</h1>
				<div class="content col-md-5 align-self-center hidden">
					<p>Ми створюємо 24 інтернет магазини в рік, і один з них може бути твій.</p>
					<p>Поспішай замовити за акційною ціною лише до 12 жовтня.</p>
					<p class="arrow">Заповнюй форму! <img src="<? echo base_url() ?>images/arrow.png" alt="Arrow"></p>
				</div>
				<div class="wrap-form col-md-7 align-self-center">
					<div class="form">
						<p class="form__text">Спеціальна пропозиція: <br>отримай чіткий план розробки твого інтернет магазину, кошторис та рекомендації щодо запуску.</p>
						<form name="form__order" class="form__order" method="post">
							<input type="text" name="form__name" id="form__name" placeholder="Ім'я" required><br>
							<input type="tel" name="form__tel" id="form__tel" pattern="^\+380\d{9}$" placeholder="Телефон" title="+380689599432" required><br>
							<input type="email" name="form__email" id="form__email" placeholder="Email" required><br>
							<button id="send_data">Отримати <br> план запуску</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</main>
	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="logo offset-1">
					<img src="<? echo base_url() ?>images/logo.png" alt="Logotype" class="logo__img">
				</div>
			<div class="copyright offset-2 offset-sm-3 offset-md-4">© All rights reserved</div>
			</div>
		</div>
	</footer>
<script type="text/javascript">
/*
	$('#send_data').on('click', (function(){

		var name = $("#form__name").val();
		var phone = $("#form__tel").val();
		var email = $("#form__email").val();
		
		$.ajax({
			type: "POST",
			url: '<? echo base_url() ?>index.php/mail_ajax',
			data: ({
				'name' : name,
				'phone' : phone,
				'email' : email
			}),
			success: ()=> alert('OK'),
			error: ()=> alert('ERROR')
		});	
	});
*/	
</script>	
</body>
</html>